
const demo = document.getElementById('monbouton');
console.log(demo)
const xhr = new XMLHttpRequest();
const url = "https://api.tisseo.fr/v2/lines.json?key=a3732a1074e2403ce364ad6e71eb998cb";
const methode = "GET";
xhr.open(methode, url);

demo.addEventListener("click", function () {
    
    xhr.onreadystatechange = function() {
        // On vérifie l'état et le statut de la requête
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log(xhr.response);
                demo.innerHTML = JSON.stringify(xhr.response, null, 2);
            } else {
                alert("Erreur: " + xhr.status + " - une erreur est survenue!!");
            }
        }
    };
    xhr.responseType = "json";
    xhr.send();
});

